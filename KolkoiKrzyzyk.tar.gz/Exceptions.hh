#pragma once

class OutOfRangePlanszaException{
public:
	void Info()const;
};

class FieldAlreadyUsedPlanszaException{
public:
	void Info()const;
};

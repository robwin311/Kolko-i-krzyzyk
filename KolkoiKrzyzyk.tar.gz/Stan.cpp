#include "Stan.hh"

/* ----------------------------------------------------------------------------------------- */
/* -------------------------------- Konstruktory/Destruktory ------------------------------- */
/* ----------------------------------------------------------------------------------------- */

Stan::Stan(int Size){
// Opis: Konstruktor klasy Stan
// IN: Size - warto�� rozmiaru planszy
// OUT: Alokuje pami�� na stan planszy

}

Stan::~Stan(){
// Opis: Destruktor klasy Stan
// IN: Brak.
// OUT: Dealokuje pami�� przydzielon� do gry
}


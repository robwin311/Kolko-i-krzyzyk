#pragma once

class Stan{
public:
	Stan(int Size);
	~Stan();
private:
	char** _Game;
};
